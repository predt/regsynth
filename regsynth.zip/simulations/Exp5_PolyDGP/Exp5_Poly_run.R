### Exp 5 : performance of different procedures
### comparision with matching estimators
### NEW DGP
### Jeremy L Hour
### 12 octobre 2016

#setwd("/Users/jeremylhour/Documents/R/regsynth-master")
setwd("//ulysse/users/JL.HOUR/1A_These/A. Research/RegSynthProject/regsynth")
rm(list=ls())

### 0. Settings

### Load packages
library("MASS")
library("ggplot2")
library("gtable")
library("grid")
library("reshape2")
library("LowRankQP")
library("xtable")

### Load user functions
source("functions/wsol.R")
source("functions/wsoll1.R")
source("functions/PolyDGP.R")
source("functions/wATT.R")
source("functions/matching.R")
source("functions/matchest.R")
source("functions/regsynth.R")
source("functions/regsynthpath.R")
source("functions/TZero.R")
source("functions/synthObj.R")
source("simulations/Exp5_PolyDGP/Exp5_Poly_setup.R")


### MC XP
set.seed(12071990)
lambda = c(seq(0.001,2,.01)) # set of lambda to be considered for optim
K = 50 # number of folds for optimal penalty level

n1 = 1; n0=50; p=1; delta=4
Exp5_Poly_setup(R=1,n1=20,n0=50,p=10,delta=2)


for(n_xp in c(2,25,50,100)){
  for(p_xp in c(1,4,8)){
    for(delta_xp in c(1,2,4)){
      Exp5_Poly_setup(R=10,n1=n_xp,n0=50,p=p_xp,delta=delta_xp)
    }
  }
}


# Problemes: (delta=2)
# bias toujours positif (MAE =  bias)
# performance du PenSynth bien inférieure
# Soit un probleme de support commun ? Pb du grid search (pass assez de lambda?) ?
# R2 is .5 for the treated but not for controls. Do the think to see where lambda CV converges
# PenSynth works when not so many controls