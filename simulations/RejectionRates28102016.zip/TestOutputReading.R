### Reading output from rejection rates
### Jeremy L Hour
### 28 octobre 2016

setwd("//ulysse/users/JL.HOUR/1A_These/A. Research/RegSynthProject/regsynth/simulations")
rm(list=ls())

### 0. Settings

### Load packages
library("MASS")
library("ggplot2")
library("stringr")

### Settup
rejrates = data.frame(rejrate1=double(),
                      rejrate2=double(),
                      rejrate3=double(),
                      n=integer(),
                      p=integer(),
                      stringsAsFactors=FALSE)

i=0
for(n in c(30,50,100)){
  for(p in c(3,10,20)){
    i=i+1; data = readLines(paste("TestOutput_n",n,",p",p,".txt",sep=""),n=7)
    rejrates[i,"n"] = word(data[1], -1)
    rejrates[i,"p"] = word(data[2], -1)
    rejrates[i,"rejrate1"] = word(data[5], -1)
    rejrates[i,"rejrate2"] = word(data[6], -1)
    rejrates[i,"rejrate3"] = word(data[7], -1)
  }
}

p <- ggplot(data = rejrates[,"p"==3], aes(x=variable, y= value, group = sample, colour=sample)) + 
  geom_line() + 
  geom_point()
